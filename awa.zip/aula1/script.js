const teste = document.querySelector(".teste")

function onClick(event){
    if(event.key == "a"){
        teste.style.witdh = 100 +"px"
    }
}

function onMouse(event){
    teste.style.left = event.x + "px"
    teste.style.top = event.y + "px"
}

document.addEventListener("mousemove", onMouse);
window.addEventListener("keydown", onClick);